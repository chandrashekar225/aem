

alert("first alert");

$(document).ready(function(){

  // jQuery methods go here...

alert("inside jquery");

});